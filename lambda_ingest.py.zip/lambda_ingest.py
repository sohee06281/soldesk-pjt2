import os
import json
import logging
from datetime import datetime, timezone

import requests
import boto3              # ✅ S3용 (Lambda 기본 내장 라이브러리)
import pg8000            # ✅ DB 레이어(pg8000) 사용

logger = logging.getLogger()
logger.setLevel(logging.INFO)

GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
YOUTUBE_ANALYTICS_URL = "https://youtubeanalytics.googleapis.com/v2/reports"
YOUTUBE_DATA_URL = "https://www.googleapis.com/youtube/v3/videos"

# ====== 새로 추가된 설정들 ======
# S3
S3_BUCKET_RAW = os.environ.get("S3_BUCKET_RAW")  # 아직 없으면 None
s3 = boto3.client("s3")

# DB
DB_HOST = os.environ.get("DB_HOST")
DB_PORT = int(os.environ.get("DB_PORT") or "5432")
DB_NAME = os.environ.get("DB_NAME")
DB_USER = os.environ.get("DB_USER")
DB_PASSWORD = os.environ.get("DB_PASSWORD")
# =============================


def get_access_token():
    """
    refresh_token으로 Google access_token 갱신
    """
    client_id = os.environ["GOOGLE_CLIENT_ID"]
    client_secret = os.environ["GOOGLE_CLIENT_SECRET"]
    refresh_token = os.environ["GOOGLE_REFRESH_TOKEN"]

    data = {
        "client_id": client_id,
        "client_secret": client_secret,
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }

    resp = requests.post(GOOGLE_TOKEN_URL, data=data, timeout=10)
    logger.info(f"[TOKEN DEBUG] status={resp.status_code}, body={resp.text}")

    if not resp.ok:
        logger.error(f"Google token error {resp.status_code}: {resp.text}")
        raise RuntimeError(
            "Failed to get access token from Google. "
            "Check GOOGLE_CLIENT_ID / SECRET / REFRESH_TOKEN and OAuth consent screen."
        )

    token_info = resp.json()
    access_token = token_info["access_token"]
    logger.info("New access token issued.")
    return access_token


def fetch_video_basic(access_token: str, video_id: str):
    """
    YouTube Data API로 영상 기본 정보 가져오기 (제목, 길이 등)
    """
    headers = {"Authorization": f"Bearer {access_token}"}
    params = {
        "part": "snippet,contentDetails,statistics",
        "id": video_id,
    }
    resp = requests.get(YOUTUBE_DATA_URL, headers=headers, params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if not data.get("items"):
        raise ValueError(f"No video found for id={video_id}")
    return data["items"][0]


def fetch_video_analytics(access_token: str, channel_id: str, video_id: str):
    """
    YouTube Analytics API로 시청 유지율/조회수 등 통계 가져오기
    (예시: 최근 7일 기준)
    """
    headers = {"Authorization": f"Bearer {access_token}"}

    end_date = datetime.now(timezone.utc).date()
    # 단순 버전: day 기준 7일 전, 월 넘어가는 건 그냥 1일까지 자름
    start_date = end_date.replace(day=max(1, end_date.day - 7))

    params = {
        "ids": f"channel=={channel_id}",
        "startDate": start_date.isoformat(),
        "endDate": end_date.isoformat(),
        "metrics": "views,averageViewDuration,averageViewPercentage,likes,comments",
        "dimensions": "video",
        "filters": f"video=={video_id}",
        "maxResults": 1,
    }

    resp = requests.get(YOUTUBE_ANALYTICS_URL, headers=headers, params=params, timeout=10)
    resp.raise_for_status()
    return resp.json()


def parse_iso8601_duration(duration_str: str) -> int:
    """
    ISO8601 기간 포맷 (예: 'PT5M30S') -> 초 단위로 변환
    """
    if not duration_str.startswith("PT"):
        return 0

    duration_str = duration_str[2:]
    total = 0
    number = ""

    units = {"H": 3600, "M": 60, "S": 1}

    for ch in duration_str:
        if ch.isdigit():
            number += ch
        else:
            if ch in units and number:
                total += int(number) * units[ch]
                number = ""
    return total


def build_insights(video_basic: dict, analytics: dict, video_id: str, channel_id: str):
    """
    Data API + Analytics API 결과를 합쳐서 분석 결과 생성
    """
    fetched_at = datetime.utcnow().replace(tzinfo=timezone.utc).isoformat()

    snippet = video_basic.get("snippet", {})
    content_details = video_basic.get("contentDetails", {})
    statistics = video_basic.get("statistics", {})

    title = snippet.get("title")
    duration_iso = content_details.get("duration", "PT0S")
    video_duration_sec = parse_iso8601_duration(duration_iso)

    rows = analytics.get("rows", [])
    if rows:
        # dimensions=video 를 사용하므로 첫 번째 값은 video_id (dimension)
        # [ video_id, views, avg_dur, avg_pct, likes, comments ]
        first_row = rows[0]
        logger.info(f"[ANALYTICS ROW DEBUG] {first_row}")

        if len(first_row) == 6:
            _, views, avg_dur, avg_pct, likes, comments = first_row
        elif len(first_row) == 5:
            # 만약 dimensions를 빼고 metrics만 쓰는 옛 포맷일 수도 있으니 방어 코드
            views, avg_dur, avg_pct, likes, comments = first_row
        else:
            raise ValueError(f"Unexpected analytics row format: {first_row}")

        views = int(views)
        avg_view_duration = int(avg_dur)
        avg_view_percent = float(avg_pct)
        likes = int(likes)
        comments = int(comments)
    else:
        views = likes = comments = 0
        avg_view_duration = 0
        avg_view_percent = 0.0

    if video_duration_sec > 0 and avg_view_duration > 0:
        retention_ratio = avg_view_duration / video_duration_sec
    else:
        retention_ratio = 0.0

    insights = {
        "video_id": video_id,
        "channel_id": channel_id,
        "title": title,
        "fetched_at": fetched_at,
        "video_duration_sec": video_duration_sec,
        "views": views,
        "likes": likes,
        "comments": comments,
        "avg_view_duration_sec": avg_view_duration,
        "avg_view_percent": avg_view_percent,
        "retention_ratio_estimated": round(retention_ratio, 3),
    }

    if views == 0:
        insights["comment"] = "최근 7일 동안 조회수가 거의 없어요."
    elif avg_view_percent >= 60:
        insights["comment"] = "시청 유지율이 꽤 좋은 편이에요 👏"
    elif avg_view_percent >= 40:
        insights["comment"] = "무난한 유지율이에요. 초반 30~40초 개선 여지가 있을 수 있어요."
    else:
        insights["comment"] = "시청 유지율이 낮은 편이에요. 썸네일/인트로/도입부를 점검해 보세요."

    return insights


def generate_detailed_feedback(insights):
    views = insights.get("views", 0)
    duration = insights.get("video_duration_sec", 1)
    avg_view_duration = insights.get("avg_view_duration_sec", 0)
    retention = insights.get("retention_ratio_estimated", 0)
    title = insights.get("title", "")

    feedback = {}

    # 전체적인 코멘트
    if views < 50:
        feedback["overall_comment"] = "조회수가 매우 적어 정확한 분석이 어려워요. 그러나 개선 포인트를 기반으로 피드백을 제공합니다."
    elif retention < 0.25:
        feedback["overall_comment"] = "이탈률이 매우 높은 편입니다. 특히 도입부 개선이 필요해요."
    elif retention < 0.5:
        feedback["overall_comment"] = "보통 수준의 이탈률입니다. 특정 구간 최적화 시 성과 향상이 가능해요."
    else:
        feedback["overall_comment"] = "시청자 유지율이 좋은 영상입니다! 알고리즘 친화적이에요."

    # 훅/도입부 피드백
    if retention < 0.25:
        feedback["hook_feedback"] = "초반에 많은 시청자가 이탈하고 있어요. 첫 5초에 강렬한 훅 또는 주요 내용을 미리 보여주는 구성이 도움이 됩니다."
    else:
        feedback["hook_feedback"] = "도입부는 비교적 안정적입니다. 현재 스타일을 유지하면서 메시지를 더 간결하게 만들면 좋아요."

    # 썸네일·제목 매칭
    if views < 100:
        feedback["thumbnail_title_match"] = "제목/썸네일은 큰 문제는 없지만, 클릭률 판단이 어려울 만큼 노출이 적어요."
    else:
        if retention < 0.3:
            feedback["thumbnail_title_match"] = "제목·썸네일과 실제 콘텐츠 매칭이 약할 수 있어요. 클릭 유도형(Clickbait)으로 오해받을 여지가 있습니다."
        else:
            feedback["thumbnail_title_match"] = "제목·썸네일과 콘텐츠가 잘 매칭됩니다."

    # 길이 대비 적정 유지율 기대값
    expected_retention = 0.45 if duration > 300 else 0.55

    if retention < expected_retention * 0.7:
        feedback["length_optimality"] = "영상 길이에 비해 시청 지속률이 낮습니다. 핵심 내용을 압축하는 것이 좋아요."
    elif retention > expected_retention:
        feedback["length_optimality"] = "영상 길이 대비 retention이 매우 우수합니다!"
    else:
        feedback["length_optimality"] = "길이 대비 평균적인 retention입니다."

    # 알고리즘 적합도 점수 (임의 스코어)
    score = (retention * 0.6) + (min(views, 1000) / 1000 * 0.4)
    feedback["algorithm_fit_score"] = round(score * 100, 1)

    if score < 0.3:
        feedback["algorithm_comment"] = "알고리즘 추천을 받기 위해선 retention 개선이 필요합니다."
    elif score < 0.6:
        feedback["algorithm_comment"] = "어느 정도 알고리즘 적합성을 갖춘 영상이에요."
    else:
        feedback["algorithm_comment"] = "알고리즘 추천 가능성이 높은 영상입니다!"

    # 다음 영상 전략
    if retention < 0.3:
        feedback["next_video_strategy"] = "짧고 임팩트 있는 클립 형태로 테스트해 보는 것을 추천합니다."
    else:
        feedback["next_video_strategy"] = "비슷한 주제의 확장 콘텐츠를 제작하면 성과가 더 좋아질 거예요."

    return feedback


# ========= 새로 추가된 저장 함수들 =========

def save_raw_to_s3(key: str, payload: dict):
    """분석 결과 전체를 S3에 JSON으로 저장"""
    if not S3_BUCKET_RAW:
        logger.warning("S3_BUCKET_RAW가 설정되지 않아 S3 저장을 건너뜁니다.")
        return

    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    s3.put_object(
        Bucket=S3_BUCKET_RAW,
        Key=key,
        Body=body,
        ContentType="application/json; charset=utf-8",
    )
    logger.info(f"[S3] Saved raw payload to s3://{S3_BUCKET_RAW}/{key}")


def save_insights_to_db(insights: dict):
    """insights 딕셔너리를 Postgres 테이블(youtube_video_insights)에 INSERT"""
    if not all([DB_HOST, DB_NAME, DB_USER, DB_PASSWORD]):
        logger.warning("DB 환경변수가 설정되지 않아 DB 저장을 건너뜁니다.")
        return

    conn = pg8000.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
    )
    try:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO youtube_video_insights (
                video_id,
                channel_id,
                title,
                fetched_at,
                video_duration_sec,
                views,
                likes,
                comments,
                avg_view_duration_sec,
                avg_view_percent,
                retention_ratio_estimated,
                comment
            )
            VALUES (
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s
            )
            """,
            (
                insights.get("video_id"),
                insights.get("channel_id"),
                insights.get("title"),
                insights.get("fetched_at"),
                insights.get("video_duration_sec"),
                insights.get("views"),
                insights.get("likes"),
                insights.get("comments"),
                insights.get("avg_view_duration_sec"),
                insights.get("avg_view_percent"),
                insights.get("retention_ratio_estimated"),
                insights.get("comment"),
            ),
        )
        conn.commit()
        logger.info("[DB] Inserted insights for video_id=%s", insights.get("video_id"))
    finally:
        conn.close()
# ==========================================


def lambda_handler(event, context):
    """
    event 예시:
    {
      "video_id": "25z9u5s6Q7I",
      "channel_id": "UC4i7oCHjZ5XnI0xC4sWv9Tg"
    }
    """
    logger.info(f"Event: {json.dumps(event)}")

    video_id = event.get("video_id")
    channel_id = event.get("channel_id")

    if not video_id or not channel_id:
        raise ValueError("video_id and channel_id are required in event.")

    # 1. access_token 발급
    access_token = get_access_token()

    # 2. Data API & Analytics 호출
    video_basic = fetch_video_basic(access_token, video_id)
    analytics = fetch_video_analytics(access_token, channel_id, video_id)

    # 3. 분석 결과 합치기
    insights = build_insights(video_basic, analytics, video_id, channel_id)

    # 4. 상세 피드백 생성
    detailed_feedback = generate_detailed_feedback(insights)

    # 5. S3 raw 저장 (insights + feedback 통째로)
    now_str = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    s3_key = f"{channel_id}/{video_id}/{now_str}.json"
    save_raw_to_s3(
        s3_key,
        {
            "video_id": video_id,
            "channel_id": channel_id,
            "insights": insights,
            "feedback": detailed_feedback,
        },
    )

    # 6. DB 저장 (실패해도 람다는 죽지 않도록 보호)
    try:
        save_insights_to_db(insights)
    except Exception:
        logger.exception("[DB] Failed to save insights")

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "message": "YouTube 분석 성공",
                "insights": insights,
                "feedback": detailed_feedback,
                "s3_key": s3_key,
            },
            ensure_ascii=False,
        ),
    }
