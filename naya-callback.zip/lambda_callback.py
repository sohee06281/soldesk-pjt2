import os
import json
import logging
import base64
from urllib.parse import urlencode

import requests
import pg8000

logger = logging.getLogger()
logger.setLevel(logging.INFO)

GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_CHANNELS_URL = "https://www.googleapis.com/youtube/v3/channels"

# ===== 환경변수 =====
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET")
REDIRECT_URI = os.environ.get("REDIRECT_URI")

DB_HOST = os.environ.get("DB_HOST")
DB_PORT = int(os.environ.get("DB_PORT") or "5432")
DB_NAME = os.environ.get("DB_NAME")
DB_USER = os.environ.get("DB_USER")
DB_PASSWORD = os.environ.get("DB_PASSWORD")

# 프론트엔드 주소 (예: https://naya.example.com )
FRONTEND_BASE_URL = os.environ.get("FRONTEND_BASE_URL")


def parse_state(state_str: str) -> dict:
    """
    OAuth state 파싱:
    - base64url(JSON) 형식이면 decode 후 dict 반환
    - 아니면 그대로 user_id에 넣어서 사용
    """
    if not state_str:
        return {}

    try:
        padding = "=" * (-len(state_str) % 4)
        decoded_bytes = base64.urlsafe_b64decode(state_str + padding)
        decoded_str = decoded_bytes.decode("utf-8")

        data = json.loads(decoded_str)
        if isinstance(data, dict):
            logger.info("[STATE] decoded JSON state: %s", data)
            return data

        logger.debug("[STATE] decoded JSON but not a dict, using raw. data=%s", data)

    except Exception as e:
        logger.debug(
            "[STATE] not a valid base64-JSON state, using raw. state=%s, error=%r",
            state_str,
            e,
        )

    return {"user_id": state_str}


def exchange_code_for_tokens(code: str):
    """
    auth code -> access_token, refresh_token 교환
    """
    if not (GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET and REDIRECT_URI):
        raise RuntimeError(
            "OAuth 환경변수(GOOGLE_CLIENT_ID/SECRET, REDIRECT_URI)가 누락되었습니다."
        )

    logger.info(
        "[DEBUG] exchange_code_for_tokens: code_len=%s, client_id=%s, redirect_uri=%s",
        len(code) if code else 0,
        GOOGLE_CLIENT_ID,
        REDIRECT_URI,
    )

    data = {
        "code": code,
        "client_id": GOOGLE_CLIENT_ID,
        "client_secret": GOOGLE_CLIENT_SECRET,
        "redirect_uri": REDIRECT_URI,
        "grant_type": "authorization_code",
    }

    resp = requests.post(GOOGLE_TOKEN_URL, data=data, timeout=10)
    logger.info("[TOKEN] status=%s, body=%s", resp.status_code, resp.text)

    if not resp.ok:
        try:
            err_json = resp.json()
        except Exception:
            err_json = {"raw": resp.text}

        logger.error(
            "[TOKEN_ERROR] failed to exchange code: %s",
            json.dumps(err_json, ensure_ascii=False),
        )
        raise RuntimeError(f"Token exchange failed: {resp.text}")

    token_info = resp.json()
    access_token = token_info.get("access_token")
    refresh_token = token_info.get("refresh_token")
    scope = token_info.get("scope", "")

    if not access_token:
        raise RuntimeError("access_token이 없습니다.")

    return access_token, refresh_token, scope


def fetch_channel_id(access_token: str) -> str:
    """
    내 채널의 channelId 조회
    """
    headers = {"Authorization": f"Bearer {access_token}"}
    params = {"part": "id", "mine": "true"}
    resp = requests.get(GOOGLE_CHANNELS_URL, headers=headers, params=params, timeout=10)
    logger.info("[CHANNEL] status=%s, body=%s", resp.status_code, resp.text)

    resp.raise_for_status()
    data = resp.json()
    items = data.get("items") or []
    if not items:
        raise RuntimeError("연결된 YouTube 채널을 찾지 못했습니다.")
    return items[0]["id"]


def save_token_to_db(user_id: str, channel_id: str, refresh_token: str, scope: str):
    """
    youtube_oauth_tokens 테이블에 (user_id, channel_id) 기준으로 upsert
    """
    if not all([DB_HOST, DB_NAME, DB_USER, DB_PASSWORD]):
        raise RuntimeError("DB 환경변수가 설정되지 않았습니다.")

    logger.info(
        "[DB] save_token_to_db 시작 (user_id=%s, channel_id=%s)",
        user_id,
        channel_id,
    )
    logger.info(
        "[DB] 접속 정보: host=%s, db=%s, user=%s, port=%s",
        DB_HOST,
        DB_NAME,
        DB_USER,
        DB_PORT,
    )

    conn = None
    try:
        logger.info("[DB] 1) DB connect 시도")
        conn = pg8000.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            timeout=5,
        )
        logger.info("[DB] 1) DB connect 성공")

        logger.info("[DB] 2) upsert 쿼리 실행")
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO youtube_oauth_tokens (
                user_id, channel_id, provider, refresh_token, scope
            )
            VALUES (%s, %s, 'google', %s, %s)
            ON CONFLICT (user_id, channel_id)
            DO UPDATE SET
                refresh_token = EXCLUDED.refresh_token,
                scope = EXCLUDED.scope,
                updated_at = now()
            """,
            (user_id, channel_id, refresh_token, scope),
        )
        conn.commit()
        logger.info(
            "[DB] 2) upsert 성공 (user_id=%s, channel_id=%s)",
            user_id,
            channel_id,
        )

    except Exception as e:
        logger.error(
            "[DB] save_token_to_db 중 에러 발생 (user_id=%s, channel_id=%s): %r",
            user_id,
            channel_id,
            e,
        )
        raise

    finally:
        if conn is not None:
            try:
                conn.close()
                logger.info("[DB] 3) DB 연결 종료")
            except Exception as e:
                logger.warning("[DB] 연결 종료 중 에러: %r", e)


def make_html_response(body_html: str, status: int = 200) -> dict:
    """
    간단 HTML 응답 래퍼
    """
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "text/html; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
        },
        "body": body_html,
    }


def make_redirect_response(url: str) -> dict:
    """
    프론트엔드로 리다이렉트 응답
    """
    return {
        "statusCode": 302,
        "headers": {
            "Location": url,
            "Access-Control-Allow-Origin": "*",
        },
        "body": "",
    }


def lambda_handler(event, context):
    logger.info(
        "[EVENT] event=%s, REDIRECT_URI_ENV=%s, GOOGLE_CLIENT_ID=%s",
        json.dumps(event),
        REDIRECT_URI,
        GOOGLE_CLIENT_ID,
    )

    try:
        qs = event.get("queryStringParameters") or {}
        code = qs.get("code")
        state_str = qs.get("state")

        if not code:
            return make_html_response("<h3>Missing authorization code</h3>", status=400)

        # 1) state 에서 user_id 복원
        state = parse_state(state_str)
        user_id = state.get("user_id") or "anonymous"
        logger.info(
            "[STATE] user_id=%s, raw_state=%s, parsed_state=%s",
            user_id,
            state_str,
            state,
        )

        # 2) 코드 교환
        access_token, refresh_token, scope = exchange_code_for_tokens(code)

        if not refresh_token:
            html = """
            <html><body>
            <h3>연결에 실패했습니다</h3>
            <p>Google에서 refresh_token을 반환하지 않았습니다.<br/>
            이미 연결된 상태였다면 Google 계정의 '앱 액세스 권한'에서 이 앱 권한을 삭제한 뒤 다시 시도해 주세요.</p>
            </body></html>
            """
            return make_html_response(html, status=400)

        # 3) 채널 id 조회
        logger.info("[DEBUG] fetching channel_id for user_id=%s", user_id)
        channel_id = fetch_channel_id(access_token)

        # 4) DB 저장
        logger.info(
            "[DEBUG] saving token: user_id=%s, channel_id=%s, scope=%s",
            user_id,
            channel_id,
            scope,
        )
        save_token_to_db(user_id, channel_id, refresh_token, scope)

        # 5) 성공 시 프론트엔드로 리다이렉트
        if not FRONTEND_BASE_URL:
            # 혹시 환경변수 안 넣어놨을 때 디버깅용
            html = f"""
            <html><body>
            <h3>채널 연결이 완료되었습니다 ✅</h3>
            <p>user_id: {user_id}<br/>channel_id: {channel_id}</p>
            <p>FRONTEND_BASE_URL 환경변수가 설정되어 있지 않아 리다이렉트는 하지 못했습니다.</p>
            </body></html>
            """
            return make_html_response(html, status=200)

        query = urlencode(
            {
                "login": "success",
                "user_id": user_id,
                "channel_id": channel_id,
            }
        )
        redirect_url = f"{FRONTEND_BASE_URL}?{query}"
        logger.info("[REDIRECT] redirect_url=%s", redirect_url)
        return make_redirect_response(redirect_url)

    except Exception as e:
        logger.exception("[CALLBACK] unhandled error: %r", e)
        html = f"""
        <html><body>
        <h3>Internal server error</h3>
        <p>{type(e).__name__}: {str(e)}</p>
        </body></html>
        """
        return make_html_response(html, status=500)
